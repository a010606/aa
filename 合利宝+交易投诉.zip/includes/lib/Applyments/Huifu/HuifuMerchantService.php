<?php

namespace lib\Applyments\Huifu;
use Exception;

require_once PLUGIN_ROOT.'huifu/inc/HuifuClient.php';

/**
 * 汇付商户进件服务
 * https://paas.huifu.com/partners/guide#/shanghu/guide_shjj
 */
class HuifuMerchantService extends \HuifuClient
{
    public function __construct($config)
    {
        parent::__construct($config);
    }

    /**
     * 商户进件
     * @param $params 进件参数
     * @return mixed
     */
    public function register($params)
    {
        $result = $this->requestApi('/v2/merchant/basicdata/ent', $params);
        if(isset($result['resp_code']) && ($result['resp_code']=='00000000' || $result['resp_code']=='90000000')) {
            return $result;
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }

    /**
     * 商户进件（个人）
     * @param $params 进件参数
     * @return mixed
     */
    public function registerMicro($params)
    {
        $result = $this->requestApi('/v2/merchant/basicdata/indv', $params);
        if(isset($result['resp_code']) && ($result['resp_code']=='00000000' || $result['resp_code']=='90000000')) {
            return $result;
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }

    /**
     * 商户信息变更
     * @param $params 参数
     * @return mixed
     */
    public function modify($params)
    {
        $result = $this->requestApi('/v2/merchant/basicdata/modify', $params);
        if(isset($result['resp_code']) && ($result['resp_code']=='00000000' || $result['resp_code']=='90000000')) {
            return $result;
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }

    /**
     * 商户业务开通
     * @param $params 参数
     * @return mixed
     */
    public function busiOpen($params)
    {
        $result = $this->requestApi('/v2/merchant/busi/open', $params);
        if(isset($result['resp_code']) && ($result['resp_code']=='00000000' || $result['resp_code']=='90000000')) {
            return $result;
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }

    /**
     * 商户业务开通修改
     * @param $params 参数
     * @return mixed
     */
    public function busiModify($params)
    {
        $result = $this->requestApi('/v2/merchant/busi/modify', $params);
        if(isset($result['resp_code']) && ($result['resp_code']=='00000000' || $result['resp_code']=='90000000')) {
            return $result;
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }

    /**
     * 商户详细信息查询
     * @param $huifu_id 汇付客户Id
     * @return mixed
     */
    public function query($huifu_id)
    {
        $params = [
            'req_seq_id' => date("YmdHis").rand(11111,99999),
            'req_date' => date("Ymd"),
            'huifu_id' => $huifu_id
        ];
        $result = $this->requestApi('/v2/merchant/basicdata/query', $params);
        if(isset($result['resp_code']) && ($result['resp_code']=='00000000' || $result['resp_code']=='90000000')) {
            return $result;
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }

    /**
     * 申请单状态查询
     * @param $apply_no 申请单号
     * @param $huifu_id 汇付客户Id
     * @return mixed
     */
    public function statusQuery($apply_no, $huifu_id)
    {
        $params = [
            'req_seq_id' => date("YmdHis").rand(11111,99999),
            'req_date' => date("Ymd"),
            'apply_no' => $apply_no,
            'huifu_id' => $huifu_id
        ];
        $result = $this->requestApi('/v2/merchant/basicdata/status/query', $params);
        if(isset($result['resp_code']) && ($result['resp_code']=='00000000' || $result['resp_code']=='90000000')) {
            return $result;
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }

    /**
     * 图片上传
     * @param $file_path 文件路径
     * @param $file_name 文件名
     * @return string
     */
    public function uploadImage($file_type, $file_path, $file_name)
    {
        $params = [
            'req_seq_id' => date("YmdHis").rand(11111,99999),
            'req_date' => date("Ymd"),
            'file_type' => $file_type,
        ];
        $result = $this->upload('/v2/supplementary/picture', $params, $file_path, $file_name);
        if(isset($result['resp_code']) && $result['resp_code']=='00000000') {
            return $result['file_id'];
        }elseif(isset($result['resp_desc'])){
            throw new Exception($result['resp_desc']);
        }else{
            throw new Exception('返回数据解析失败');
        }
    }
}