<?php
if(!defined('IN_CRONLITE'))exit();?>
<form onsubmit="return searchSubmit()" method="GET" class="form-inline" id="searchToolbar">
<input type="hidden" name="type" value="page">
<input type="hidden" name="action" value="report">
<input type="hidden" name="id" value="<?php echo $row['id']?>">
<input type="hidden" name="act" value="list">
  <div class="form-group">
    <label>快钱已报备商户</label>
	<input type="text" class="form-control" name="keyword" placeholder="报备子商户号">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>
  <a href="./applyments_form.php?type=page&action=report&id=<?php echo $row['id']?>&act=add" class="btn btn-success">新增报备</a>
</form>

<table id="listTable">
</table>
<?php register_shutdown_function(function() use($row, $cdnpublic){?>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.js"></script>
<script src="../assets/js/bootstrap-table.min.js"></script>
<script src="../assets/js/bootstrap-table-page-jump-to.min.js"></script>
<script src="https://s4.zstatic.net/ajax/libs/bootstrap-table/1.21.4/extensions/export/bootstrap-table-export.min.js"></script>
<script src="https://s4.zstatic.net/ajax/libs/xlsx/0.18.5/xlsx.core.min.js"></script>
<script src="https://gcore.jsdelivr.net/npm/tableexport.jquery.plugin@1.30.0/tableExport.min.js"></script>
<script src="../assets/js/custom.js"></script>
<script>
$(document).ready(function(){
	updateToolbar();
	const defaultPageSize = 30;
	const pageNumber = typeof window.$_GET['pageNumber'] != 'undefined' ? parseInt(window.$_GET['pageNumber']) : 1;
	const pageSize = typeof window.$_GET['pageSize'] != 'undefined' ? parseInt(window.$_GET['pageSize']) : defaultPageSize;

	$("#listTable").bootstrapTable({
		url: 'ajax_applyments.php?act=query',
		pageNumber: pageNumber,
		pageSize: pageSize,
		sidePagination: 'client',
		showExport: true,
		exportDataType: 'all',
		exportTypes: ['csv', 'txt', 'excel', 'xlsx'],
		classes: 'table table-striped table-hover table-bordered',
		columns: [
			{
				field: 'id',
				title: 'ID',
				formatter: function(value, row, index) {
					return '<b>'+value+'</b>';
				}
			},
			{
				field: 'report_channel',
				title: '报备通道名称'
			},
			{
				field: 'report_submchid',
				title: '报备子商户号'
			},
			{
				field: 'addtime',
				title: '添加时间'
			},
		],
	})
})
</script>
<?php });?>