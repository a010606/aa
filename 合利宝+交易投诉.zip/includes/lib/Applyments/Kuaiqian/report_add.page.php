<?php
if(!defined('IN_CRONLITE'))exit();?>
	  <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">快钱商户新增报备<span class="pull-right"><a class="btn btn-default btn-xs" href="./applyments_form.php?type=page&action=report&id=<?php echo $row['id']?>">返回</a></span></h3></div>
        <div class="panel-body">
          <form action="./applyments_form.php?type=page&action=report&id=<?php echo $row['id']?>" method="POST" class="form-horizontal" role="form">
			<div class="form-group">
				<label class="col-sm-3 control-label">要报备的支付方式</label>
				<div class="col-sm-7"><div class="checkbox"><label><input type="checkbox" checked name="pay_type[]" value="wechat">微信支付</label>&nbsp;<label><input type="checkbox" checked name="pay_type[]" value="alipay">支付宝</label></div></div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">商户分类码</label>
				<div class="col-sm-7"><input type="text" name="mcc" value="" placeholder="4位银联mcc，不填则使用前一次报备成功的数据" class="form-control"></div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">商户简称</label>
				<div class="col-sm-7"><input type="text" name="shortName" value="" placeholder="用于微信/支付宝账单页面展示，不填则使用前一次报备成功的数据" class="form-control"></div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">客服电话</label>
				<div class="col-sm-7"><input type="text" name="servicePhone" value="" placeholder="不填则使用前一次报备成功的数据" class="form-control"></div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">报备数量</label>
				<div class="col-sm-7"><input type="number" name="num" value="1" min="1" placeholder="" class="form-control"></div>
			</div>
			<div class="form-group">
				<div class="col-sm-offset-3 col-sm-7"><input type="submit" name="submit" value="提交" class="btn btn-primary form-control"><br>
			</div>
			</div>
          </form>
        </div>
		<div class="panel-footer">
          <span class="glyphicon glyphicon-info-sign"></span> 商户分类码参考：MCC行业代码.xlsx
        </div>
      </div>
