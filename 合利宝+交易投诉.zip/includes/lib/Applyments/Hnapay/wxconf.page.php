<?php
if(!defined('IN_CRONLITE'))exit();?>
<style>tbody tr>td:nth-child(1){width:180px}</style>
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">当前配置查询<span class="pull-right"><a class="btn btn-default btn-xs" href="./applyments_form.php?type=page&action=wxconf&id=<?php echo $row['id']?>">刷新</a></span></h3></div>
<div class="panel-body">
<p><b>已关联的公众号AppID：</b></p>
<p><?php foreach($data['appid_config_list'] as $item){ echo $item['subAppid'].'<br/>';}?></p>
<p><b>JSAPI支付授权目录：</b></p>
<p><?php foreach($data['jsapi_path_list'] as $item){ echo $item['jsapiPath'].'<br/>';}?></p>
</div>
</div>
<div class="panel panel-success">
<div class="panel-heading"><h3 class="panel-title">微信参数配置</span></h3></div>
<div class="panel-body">
	<form action="./applyments_form.php?type=page&action=wxconf&id=<?php echo $row['id']?>" method="POST" class="form-horizontal" role="form">
		<div class="form-group">
			<label class="col-sm-3 control-label">公众号/小程序AppID</label>
			<div class="col-sm-7"><input type="text" name="subAppid" value="" placeholder="只能填写已认证的服务号或小程序，一次只能提交1个" class="form-control" required></div>
		</div>
		<div class="form-group">
			<label class="col-sm-3 control-label">JSAPI支付授权目录</label>
			<div class="col-sm-7"><input type="text" name="jsapiPath" value="<?php echo $siteurl?>" placeholder="必须以http://或https://开头，以/结尾" class="form-control" required></div>
		</div>
		<div class="form-group">
			<div class="col-sm-offset-3 col-sm-7"><input type="submit" name="submit" value="新增" class="btn btn-primary form-control"><br>
		</div>
		</div>
	</form>
</div>
</div>